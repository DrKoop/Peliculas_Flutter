package com.example.peliculas_drkoop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
