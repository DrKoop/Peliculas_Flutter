/* -------------------------------------------------------------------------- */
/*                         MAIN DE EL CONSUMO DE API's                        */
/* -------------------------------------------------------------------------- */

import 'dart:convert';
//import 'dart:html';

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:peliculas_drkoop/models/models.dart';
import 'package:peliculas_drkoop/models/search_response.dart';

class MoviesProvider extends ChangeNotifier{

  //Propiedades
  final String _apikey = 'a3c16502c7a045790edb4452141ac728';
  final String _baseUrl = 'api.themoviedb.org';
  final String _language = 'en-ES';

  List<Movie> OnDisplayMovies = [];
  List<Movie> popularMovies = [];
  Map< int, List<Cast>> movieCast = {};

  int _popularPage = 0;

  MoviesProvider(){
    print(' Movies ejecutando ...');
    getOnDisplayMovies();
    getPopularMovies();
  }

  Future<String> _getJsonData( String endpoint , [ int page = 1]) async{
    final url = Uri.https( _baseUrl, endpoint, {
      'api_key' : _apikey,
      'language' : _language,
      'page' : '$page'
    });

    final response = await http.get(url);
    return response.body;
  }

  //Consultando el endpoint de la API
  getOnDisplayMovies() async{

    final jsonData = await this._getJsonData('/3/movie/now_playing');
    final nowPlayingResponse = NowPlayingResponse.fromJson(jsonData);
    //final Map<String, dynamic> decodeData = json.decode( response.body);
    //print( nowPlayingResponse.results[1].title );
    OnDisplayMovies = nowPlayingResponse.results;
    notifyListeners();
  }

  //LISTANDO PELICULAS POPULARES
  getPopularMovies() async {

    _popularPage++;
    final jsonData = await this._getJsonData('/3/movie/popular', _popularPage);
    final popularResponse = PopularResponse.fromJson(jsonData);
    popularMovies = [...popularMovies,...popularResponse.results];
    print(popularMovies[0]);
    notifyListeners();
  }


  //Listando el casting
 Future<List<Cast>> getMovieCast( int movieId ) async{
     
     if( movieCast.containsKey(movieId)) return movieCast[movieId]!;

     final jsonData = await this._getJsonData('/3/movie/$movieId/credits');
     final creditsResponse = CreditsResponse.fromJson(jsonData);
     movieCast[movieId] = creditsResponse.cast;
     return creditsResponse.cast;
  }

  //Filtrar resultados busquedas
  Future<List<Movie>> searchMovies( String query) async{
    final url = Uri.https( _baseUrl, '3/search/movie', {
      'api_key' : _apikey,
      'language' : _language,
      'query' : query
    });

    final response = await http.get(url);
    final searhResponse = SearchResponse.fromJson(response.body);
    return searhResponse.results;
  }


}