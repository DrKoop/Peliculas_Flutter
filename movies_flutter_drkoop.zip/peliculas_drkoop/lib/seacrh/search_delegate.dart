
import 'package:flutter/material.dart';

import 'package:flutter/material.dart';
import 'package:peliculas_drkoop/models/models.dart';
import 'package:peliculas_drkoop/providers/movies_provider.dart';
import 'package:provider/provider.dart';

class MovieSearchDelegate extends SearchDelegate{
  //Traduccion a español en el label de filtra de busqueda
  @override
  String? get searchFieldLabel => 'Buscar';
  


  @override
  List<Widget>? buildActions(BuildContext context) {
      
      return [
        IconButton(
          icon: Icon(Icons.clear),
          onPressed : () => query = '',
          )
        
      ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    //regresar a la pantalla anterior
    return IconButton(
      icon: Icon( Icons.arrow_back),
      onPressed: (){
        close(context, null);
      },
      );
  }

  @override
  Widget buildResults(BuildContext context) {
    return Text('desde build Result');
  }

  Widget _emptyContainer(){
    return Container(
        child: Center(
          child: Icon( Icons.movie_creation_outlined, color: Colors.black38, size: 100,),
          ),
      );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    
    if( query.isEmpty){
      return _emptyContainer();
    }
    //Llamando al future desde el provider
    
    final moviesProvider = Provider.of<MoviesProvider>(context, listen: false);

    return FutureBuilder(
      future: moviesProvider.searchMovies(query),
      builder: (_,  AsyncSnapshot<List<Movie>> snapshot){

        //Si no se encontro la busqueda
        if( !snapshot.hasData){
          return _emptyContainer();
        } 

        final movies = snapshot.data!;

        return ListView.builder(
            itemCount: movies.length,
            itemBuilder: (_, int index) => _MovieItem( movies[index] )
        );
      },
      );
  }
}



//Para que no se extienda tanto el constructor principal, (aca tambien se practica las clases privadas), creamos una clase que solo va a retornar una vista de los que tiene que listar el contenedor que muestre los resultados de la busqueda
class _MovieItem extends StatelessWidget {
  final Movie movie;
  const _MovieItem(this.movie);
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: FadeInImage(
        // ignore: prefer_const_constructors
        placeholder:  AssetImage('lib/assets/no-image.jpg'),
        image: NetworkImage(movie.fullPosterimg),
        width: 50,
        fit: BoxFit.contain,
      ),
      title: Text(movie.title),
      subtitle: Text(movie.originalTitle),
      onTap: () {
        Navigator.pushNamed(context, 'details', arguments: movie);
      },
    );
  }
}