export 'package:peliculas_drkoop/widgets/card_swiper.dart';

export 'package:peliculas_drkoop/widgets/movie_slider.dart';
