import 'package:flutter/material.dart';
import 'package:peliculas_drkoop/providers/movies_provider.dart';
import 'package:provider/provider.dart';
import '../seacrh/search_delegate.dart';
import '../widgets/widgets.dart';

class HomeScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    final moviesProvider = Provider.of<MoviesProvider>(context);
    print(moviesProvider.OnDisplayMovies);


    return Scaffold(
      appBar: AppBar(
        title: Text('Peliculas Gratis'),
        elevation: 0,
        actions: [
          IconButton(
           icon: Icon( Icons.search_outlined),
           onPressed: () => showSearch(context: context, delegate: MovieSearchDelegate()),
             )
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            /* Tarjetas principales */
            CardSwiper( movies: moviesProvider.OnDisplayMovies ),
            /* Slider de pleiculas */
            MovieSlider(
              movies : moviesProvider.popularMovies, //Me comento con la clase provider y accedo al metodo de peliculas populares
              title : 'Populares',
              onNextPage: () => moviesProvider.getPopularMovies(),
            ),
          ],
          ),
      )
    );
  }
}